<?php
define("SITE_TITLE", "Taracode");
define("TIME_ZONE", "Europe/London");
define("DATE_FORMAT", "%F");
define("TIME_FORMAT", "%I:%M %P");
define("CURRENCY_ENABLED", "1");
define("LANG_ENABLED", "0");
define("ENABLE_COOKIES_NOTICE", "1");
define("MAINTENANCE_MODE", "0");
define("MAINTENANCE_MSG", "<h1><i class=\"fa fa-rocket\"></i> Тун удахгүй...</h1><p>Сайт засвартай байна.</p>");
define("TEMPLATE", "default");
define("OWNER", "");
define("EMAIL", "admin@admin.com");
define("ADDRESS", "");
define("PHONE", "");
define("MOBILE", "");
define("FAX", "");
define("DB_NAME", "taracode");
define("DB_HOST", "localhost");
define("DB_PORT", "3306");
define("DB_USER", "admin");
define("DB_PASS", "admin");
define("SENDER_EMAIL", "");
define("SENDER_NAME", "");
define("USE_SMTP", "0");
define("SMTP_SECURITY", "");
define("SMTP_AUTH", "0");
define("SMTP_HOST", "");
define("SMTP_USER", "");
define("SMTP_PASS", "");
define("SMTP_PORT", "25");
define("GMAPS_API_KEY", "");
define("ANALYTICS_CODE", "");
define("ADMIN_FOLDER", "admin");
define("PAYMENT_TYPE", "arrival"); // cards,paypal,check,arrival
define("PAYPAL_EMAIL", "");
define("VENDOR_ID", ""); // 2Checkout.com account number
define("SECRET_WORD", ""); // 2Checkout.com secret word
define("PAYMENT_TEST_MODE", "1");
define("ENABLE_DOWN_PAYMENT", "1");
define("DOWN_PAYMENT_RATE", "30"); // %
define("ENABLE_TOURIST_TAX", "1");
define("TOURIST_TAX", "0");
define("TOURIST_TAX_TYPE", "fixed");
define("ALLOW_COMMENTS", "1");
define("ALLOW_RATINGS", "1"); // If comments enabled
define("ENABLE_BOOKING_REQUESTS", "0"); // Possibility to make a reservation request if no availability
