var months			= ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Decembre'],
	days			= ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'],
	errorMessage	= 'Error loading events...';
