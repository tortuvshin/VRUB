var months			= ['January','February','March','April','May','June','July','August','September','October','November','December'],
	days			= ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
	errorMessage	= 'Error loading events...';