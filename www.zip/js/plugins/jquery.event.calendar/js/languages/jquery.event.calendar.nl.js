var months			= ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
	days			= ['Mo','Di','Mi','Do','Fr','Sa','So'],
	errorMessage	= 'Fehler beim Laden der Ereignisse...';