var months			= ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'],
	days			= ['Pzt','Sal','Çar','Per','Cum','Cts','Pz'],
	errorMessage	= 'Etkinlikler yüklenirken bir hata oluştu...';